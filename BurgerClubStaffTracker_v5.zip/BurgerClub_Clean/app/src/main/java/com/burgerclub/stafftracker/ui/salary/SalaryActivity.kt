package com.burgerclub.stafftracker.ui.salary

import android.app.DatePickerDialog
import android.content.ContentValues
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.burgerclub.stafftracker.data.db.AppDatabase
import com.burgerclub.stafftracker.data.model.Employee
import com.burgerclub.stafftracker.data.model.ShiftRecord
import com.burgerclub.stafftracker.databinding.ActivitySalaryBinding
import com.burgerclub.stafftracker.utils.DateUtils
import com.burgerclub.stafftracker.utils.SalaryCalculator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.OutputStreamWriter
import java.util.*

class SalaryActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySalaryBinding
    private lateinit var adapter: SalaryAdapter
    private var filterFrom: Long = 0L
    private var filterTo: Long = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySalaryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.title = "Расчёт зарплаты"

        adapter = SalaryAdapter()
        binding.rvSalary.layoutManager = LinearLayoutManager(this)
        binding.rvSalary.adapter = adapter

        // Default: current month
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        filterFrom = cal.timeInMillis
        filterTo = System.currentTimeMillis()
        binding.btnFrom.text = "С: ${DateUtils.formatDate(filterFrom)}"
        binding.btnTo.text = "По: ${DateUtils.formatDate(filterTo)}"

        binding.btnCurrentMonth.setOnClickListener { setCurrentMonth() }
        binding.btnLastMonth.setOnClickListener { setLastMonth() }
        binding.btnFrom.setOnClickListener { pickDate(true) }
        binding.btnTo.setOnClickListener { pickDate(false) }
        binding.btnExport.setOnClickListener { exportSalary() }

        loadSalary()
    }

    private fun setCurrentMonth() {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        filterFrom = cal.timeInMillis
        filterTo = System.currentTimeMillis()
        binding.btnFrom.text = "С: ${DateUtils.formatDate(filterFrom)}"
        binding.btnTo.text = "По: ${DateUtils.formatDate(filterTo)}"
        loadSalary()
    }

    private fun setLastMonth() {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        cal.add(Calendar.MONTH, -1)
        filterFrom = cal.timeInMillis
        cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH))
        cal.set(Calendar.HOUR_OF_DAY, 23); cal.set(Calendar.MINUTE, 59); cal.set(Calendar.SECOND, 59)
        filterTo = cal.timeInMillis
        binding.btnFrom.text = "С: ${DateUtils.formatDate(filterFrom)}"
        binding.btnTo.text = "По: ${DateUtils.formatDate(filterTo)}"
        loadSalary()
    }

    private fun pickDate(isFrom: Boolean) {
        val cal = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            val picked = Calendar.getInstance().apply {
                set(y, m, d, if (isFrom) 0 else 23, if (isFrom) 0 else 59, 0)
            }.timeInMillis
            if (isFrom) {
                filterFrom = picked
                binding.btnFrom.text = "С: ${DateUtils.formatDate(picked)}"
            } else {
                filterTo = picked
                binding.btnTo.text = "По: ${DateUtils.formatDate(picked)}"
            }
            loadSalary()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    data class EmployeeSalarySummary(
        val employee: Employee,
        val records: List<ShiftRecord>,
        val totalHours: Double,
        val totalSalary: Double,
        val lateCount: Int,
        val shiftsCount: Int
    )

    private fun loadSalary() {
        lifecycleScope.launch(Dispatchers.IO) {
            val db = AppDatabase.getDatabase(this@SalaryActivity)
            val employees = db.employeeDao().getAllEmployeesList()
            val allRecords = db.shiftRecordDao().getAllRecordsList()

            val summaries = employees.map { emp ->
                val empRecords = allRecords.filter {
                    it.employeeId == emp.id &&
                    it.checkOutTime != null &&
                    it.checkInTime >= filterFrom &&
                    it.checkInTime <= filterTo
                }
                val totalHours = empRecords.sumOf { it.billedHours }
                val totalSalary = empRecords.sumOf { it.salary }
                val lateCount = empRecords.count { it.isLate }
                EmployeeSalarySummary(emp, empRecords, totalHours, totalSalary, lateCount, empRecords.size)
            }.filter { it.shiftsCount > 0 || true } // show all employees

            val totalAll = summaries.sumOf { it.totalSalary }
            val hoursAll = summaries.sumOf { it.totalHours }

            withContext(Dispatchers.Main) {
                adapter.submitList(summaries)
                binding.tvTotalSalary.text = "Итого к выплате: ${String.format("%,.0f", totalAll)} ₽"
                binding.tvTotalHours.text = "Всего часов: ${SalaryCalculator.formatHours(hoursAll)}"
                binding.tvPeriod.text = "${DateUtils.formatDate(filterFrom)} — ${DateUtils.formatDate(filterTo)}"
            }
        }
    }

    private fun exportSalary() {
        lifecycleScope.launch(Dispatchers.IO) {
            val items = adapter.currentList
            val sb = StringBuilder()
            sb.appendLine("Сотрудник;Смен;Часов;Опозданий;Зарплата (руб)")
            for (item in items) {
                sb.appendLine("${item.employee.name};${item.shiftsCount};${String.format("%.2f", item.totalHours)};${item.lateCount};${String.format("%.2f", item.totalSalary)}")
            }
            sb.appendLine("ИТОГО;;;${items.sumOf { it.lateCount }};${String.format("%.2f", items.sumOf { it.totalSalary })}")

            try {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, "salary_${DateUtils.fileTimestamp()}.csv")
                    put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                uri?.let { u ->
                    contentResolver.openOutputStream(u)?.use { os ->
                        OutputStreamWriter(os, Charsets.UTF_8).use { it.write(sb.toString()) }
                    }
                }
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@SalaryActivity, "✅ Экспортировано в Downloads", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@SalaryActivity, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
