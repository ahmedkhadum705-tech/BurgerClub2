package com.burgerclub.stafftracker.ui.employees

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.burgerclub.stafftracker.data.db.AppDatabase
import com.burgerclub.stafftracker.data.model.Employee
import com.burgerclub.stafftracker.databinding.ActivityEmployeeEditBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class EmployeeEditActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEmployeeEditBinding
    private var employeeId: Long = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEmployeeEditBinding.inflate(layoutInflater)
        setContentView(binding.root)

        employeeId = intent.getLongExtra("employee_id", -1L)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        if (employeeId != -1L) {
            binding.toolbar.title = "Редактировать"
            loadEmployee(employeeId)
        } else {
            binding.toolbar.title = "Новый сотрудник"
        }

        binding.btnSave.setOnClickListener { saveEmployee() }
    }

    private fun loadEmployee(id: Long) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val db = AppDatabase.getDatabase(this@EmployeeEditActivity)
                val emp = db.employeeDao().getEmployee(id) ?: return@launch
                withContext(Dispatchers.Main) {
                    binding.etName.setText(emp.name)
                    binding.etRate.setText(emp.hourlyRate.toInt().toString())
                    binding.etPin.setText(emp.pinCode)
                    binding.etShiftStart.setText(emp.shiftStartTime)
                }
            } catch (e: Exception) {
                Log.e("EmployeeEdit", "Load error", e)
            }
        }
    }

    private fun saveEmployee() {
        val name = binding.etName.text?.toString()?.trim() ?: ""
        val rateStr = binding.etRate.text?.toString()?.trim() ?: ""
        val pin = binding.etPin.text?.toString()?.trim() ?: ""
        val shiftStart = binding.etShiftStart.text?.toString()?.trim() ?: ""

        // Validation
        if (name.isEmpty()) {
            binding.etName.error = "Введите имя"
            return
        }
        if (rateStr.isEmpty()) {
            binding.etRate.error = "Введите ставку"
            return
        }
        val rate = rateStr.toDoubleOrNull()
        if (rate == null || rate <= 0) {
            binding.etRate.error = "Введите корректную ставку"
            return
        }
        if (pin.length < 4) {
            binding.etPin.error = "PIN минимум 4 цифры"
            return
        }
        // Accept formats: "9:00", "09:00", "10:00"
        val timeRegex = Regex("^\\d{1,2}:\\d{2}$")
        if (!shiftStart.matches(timeRegex)) {
            binding.etShiftStart.error = "Формат: HH:MM (например 09:00)"
            return
        }

        binding.btnSave.isEnabled = false

        val employee = Employee(
            id = if (employeeId == -1L) 0L else employeeId,
            name = name,
            hourlyRate = rate,
            pinCode = pin,
            shiftStartTime = shiftStart,
            isOnShift = false
        )

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val db = AppDatabase.getDatabase(this@EmployeeEditActivity)
                if (employeeId == -1L) {
                    db.employeeDao().insert(employee)
                } else {
                    db.employeeDao().update(employee)
                }
                withContext(Dispatchers.Main) {
                    val msg = if (employeeId == -1L) "Сотрудник добавлен ✅" else "Данные сохранены ✅"
                    Toast.makeText(this@EmployeeEditActivity, msg, Toast.LENGTH_SHORT).show()
                    finish()
                }
            } catch (e: Exception) {
                Log.e("EmployeeEdit", "Save error", e)
                withContext(Dispatchers.Main) {
                    binding.btnSave.isEnabled = true
                    Toast.makeText(this@EmployeeEditActivity, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
