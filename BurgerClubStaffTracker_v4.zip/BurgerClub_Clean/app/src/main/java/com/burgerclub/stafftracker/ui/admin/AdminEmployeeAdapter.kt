package com.burgerclub.stafftracker.ui.admin

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.burgerclub.stafftracker.data.model.Employee
import com.burgerclub.stafftracker.databinding.ItemEmployeeAdminBinding

class AdminEmployeeAdapter(
    private val onEdit: (Employee) -> Unit,
    private val onDelete: (Employee) -> Unit
) : ListAdapter<Employee, AdminEmployeeAdapter.VH>(DIFF) {

    private val avatarColors = listOf(
        "#0A84FF", "#30D158", "#FF9F0A", "#FF453A",
        "#BF5AF2", "#5AC8FA", "#FF6B6B", "#4ECDC4"
    )

    inner class VH(private val b: ItemEmployeeAdminBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(emp: Employee, position: Int) {
            val initials = emp.name.split(" ")
                .mapNotNull { it.firstOrNull()?.uppercaseChar() }
                .take(2).joinToString("")
            b.tvInitialAdmin.text = initials.ifEmpty { emp.name.take(1).uppercase() }
            b.tvInitialAdmin.background.setTint(Color.parseColor(avatarColors[position % avatarColors.size]))

            b.tvName.text = emp.name
            b.tvDetails.text = "${emp.hourlyRate.toInt()} ₽/ч  ·  смена с ${emp.shiftStartTime}"
            b.tvStatus.text = if (emp.isOnShift) "● На смене" else "○ Не работает"
            b.tvStatus.setTextColor(
                if (emp.isOnShift) b.root.context.getColor(com.burgerclub.stafftracker.R.color.green_success)
                else b.root.context.getColor(com.burgerclub.stafftracker.R.color.text_tertiary)
            )
            b.btnEdit.setOnClickListener { onEdit(emp) }
            b.btnDelete.setOnClickListener { onDelete(emp) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemEmployeeAdminBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position), position)

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Employee>() {
            override fun areItemsTheSame(a: Employee, b: Employee) = a.id == b.id
            override fun areContentsTheSame(a: Employee, b: Employee) = a == b
        }
    }
}
