package com.burgerclub.stafftracker.ui.journal

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.ContentValues
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.burgerclub.stafftracker.data.db.AppDatabase
import com.burgerclub.stafftracker.databinding.ActivityJournalBinding
import com.burgerclub.stafftracker.utils.DateUtils
import kotlinx.coroutines.launch
import java.io.OutputStreamWriter
import java.util.*

class JournalActivity : AppCompatActivity() {

    private lateinit var binding: ActivityJournalBinding
    private lateinit var adapter: JournalAdapter
    private var filterFrom: Long = 0L
    private var filterTo: Long = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityJournalBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.title = "Журнал смен"

        adapter = JournalAdapter { record ->
            // Show photos dialog
            showPhotosDialog(record.checkInPhotoPath, record.checkOutPhotoPath)
        }
        binding.rvJournal.layoutManager = LinearLayoutManager(this)
        binding.rvJournal.adapter = adapter

        binding.btnFilterFrom.setOnClickListener { pickDate(true) }
        binding.btnFilterTo.setOnClickListener { pickDate(false) }
        binding.btnResetFilter.setOnClickListener { resetFilter() }
        binding.btnExportCsv.setOnClickListener { exportCsv() }

        loadAll()
    }

    private fun loadAll() {
        AppDatabase.getDatabase(this).shiftRecordDao().getAllRecords().observe(this) { list ->
            adapter.submitList(list)
            val totalSalary = list.sumOf { it.salary }
            val totalHours = list.sumOf { it.billedHours }
            binding.tvSummary.text = "Записей: ${list.size}  |  ${String.format("%.1f", totalHours)} ч  |  ${String.format("%.0f", totalSalary)} руб"
        }
    }

    private fun pickDate(isFrom: Boolean) {
        val cal = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            val picked = Calendar.getInstance().apply {
                set(y, m, d, 0, 0, 0)
                set(Calendar.MILLISECOND, 0)
            }.timeInMillis

            if (isFrom) {
                filterFrom = picked
                binding.btnFilterFrom.text = "От: ${DateUtils.formatDate(picked)}"
            } else {
                filterTo = DateUtils.endOfDay(picked)
                binding.btnFilterTo.text = "До: ${DateUtils.formatDate(picked)}"
            }
            applyFilter()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun applyFilter() {
        if (filterFrom == 0L || filterTo == 0L) return
        AppDatabase.getDatabase(this).shiftRecordDao()
            .getRecordsByDateRange(filterFrom, filterTo).observe(this) { list ->
                adapter.submitList(list)
            }
    }

    private fun resetFilter() {
        filterFrom = 0L; filterTo = 0L
        binding.btnFilterFrom.text = "Дата от"
        binding.btnFilterTo.text = "Дата до"
        loadAll()
    }

    private fun exportCsv() {
        lifecycleScope.launch {
            val records = AppDatabase.getDatabase(this@JournalActivity).shiftRecordDao().getAllRecordsList()
            val sb = StringBuilder()
            sb.appendLine("Сотрудник;Вход;Выход;Часы;Зарплата;Опоздание;Мин опоздания")
            for (r in records) {
                val checkOut = if (r.checkOutTime != null) DateUtils.formatTimestamp(r.checkOutTime) else "—"
                sb.appendLine("${r.employeeName};${DateUtils.formatTimestamp(r.checkInTime)};$checkOut;${String.format("%.2f", r.billedHours)};${String.format("%.2f", r.salary)};${if (r.isLate) "Да" else "Нет"};${r.lateMinutes}")
            }

            try {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, "staff_report_${DateUtils.fileTimestamp()}.csv")
                    put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                uri?.let { u ->
                    contentResolver.openOutputStream(u)?.use { os ->
                        OutputStreamWriter(os, Charsets.UTF_8).use { w -> w.write(sb.toString()) }
                    }
                    Toast.makeText(this@JournalActivity, getString(com.burgerclub.stafftracker.R.string.export_success), Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@JournalActivity, "Ошибка экспорта: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showPhotosDialog(checkInPath: String?, checkOutPath: String?) {
        if (checkInPath == null && checkOutPath == null) {
            Toast.makeText(this, "Нет фото для этой смены", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = android.content.Intent(this, PhotoViewActivity::class.java).apply {
            putExtra("photo_in", checkInPath)
            putExtra("photo_out", checkOutPath)
        }
        startActivity(intent)
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
