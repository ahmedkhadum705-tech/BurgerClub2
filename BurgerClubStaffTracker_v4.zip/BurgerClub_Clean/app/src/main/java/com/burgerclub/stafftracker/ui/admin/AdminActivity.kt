package com.burgerclub.stafftracker.ui.admin

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.burgerclub.stafftracker.data.db.AppDatabase
import com.burgerclub.stafftracker.data.model.Employee
import com.burgerclub.stafftracker.databinding.ActivityAdminBinding
import com.burgerclub.stafftracker.ui.employees.EmployeeEditActivity
import com.burgerclub.stafftracker.ui.journal.JournalActivity
import com.burgerclub.stafftracker.ui.rating.RatingActivity
import kotlinx.coroutines.launch

class AdminActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAdminBinding
    private lateinit var adapter: AdminEmployeeAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdminBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.title = "Панель администратора"

        adapter = AdminEmployeeAdapter(
            onEdit = { emp -> editEmployee(emp) },
            onDelete = { emp -> confirmDelete(emp) }
        )
        binding.rvEmployees.layoutManager = LinearLayoutManager(this)
        binding.rvEmployees.adapter = adapter

        binding.btnAddEmployee.setOnClickListener {
            startActivity(Intent(this, EmployeeEditActivity::class.java))
        }
        binding.btnJournal.setOnClickListener {
            startActivity(Intent(this, JournalActivity::class.java))
        }
        binding.btnRating.setOnClickListener {
            startActivity(Intent(this, RatingActivity::class.java))
        }

        loadEmployees()
    }

    override fun onResume() {
        super.onResume()
        loadEmployees()
    }

    private fun loadEmployees() {
        val db = AppDatabase.getDatabase(this)
        db.employeeDao().getAllEmployees().observe(this) { list ->
            adapter.submitList(list)
        }
    }

    private fun editEmployee(emp: Employee) {
        val intent = Intent(this, EmployeeEditActivity::class.java)
        intent.putExtra("employee_id", emp.id)
        startActivity(intent)
    }

    private fun confirmDelete(emp: Employee) {
        AlertDialog.Builder(this)
            .setTitle("Удалить сотрудника")
            .setMessage("Удалить ${emp.name}? Все данные смен будут удалены.")
            .setPositiveButton("Удалить") { _, _ ->
                lifecycleScope.launch {
                    AppDatabase.getDatabase(this@AdminActivity).employeeDao().delete(emp)
                    Toast.makeText(this@AdminActivity, "${emp.name} удалён", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
