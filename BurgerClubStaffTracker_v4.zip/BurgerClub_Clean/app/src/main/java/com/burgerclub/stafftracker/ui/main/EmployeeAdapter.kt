package com.burgerclub.stafftracker.ui.main

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.burgerclub.stafftracker.data.model.Employee
import com.burgerclub.stafftracker.databinding.ItemEmployeeCardBinding

class EmployeeAdapter(
    private val onClick: (Employee) -> Unit
) : ListAdapter<Employee, EmployeeAdapter.VH>(DIFF) {

    private var selectedId: Long = -1L

    // Palette of colors for avatars
    private val avatarColors = listOf(
        "#0A84FF", "#30D158", "#FF9F0A", "#FF453A",
        "#BF5AF2", "#5AC8FA", "#FF6B6B", "#4ECDC4"
    )

    fun setSelected(id: Long) {
        val old = currentList.indexOfFirst { it.id == selectedId }
        val new = currentList.indexOfFirst { it.id == id }
        selectedId = id
        if (old >= 0) notifyItemChanged(old)
        if (new >= 0) notifyItemChanged(new)
    }

    inner class VH(private val b: ItemEmployeeCardBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(emp: Employee, position: Int) {
            // Initials
            val initials = emp.name.split(" ")
                .mapNotNull { it.firstOrNull()?.uppercaseChar() }
                .take(2).joinToString("")
            b.tvInitial.text = initials.ifEmpty { emp.name.take(1).uppercase() }

            // Avatar color based on position
            val color = avatarColors[position % avatarColors.size]
            b.tvInitial.background.setTint(Color.parseColor(color))

            b.tvName.text = emp.name
            b.tvRate.text = "${emp.hourlyRate.toInt()} ₽/ч"
            b.tvShiftStart.text = "с ${emp.shiftStartTime}"

            // Status dot
            b.ivStatus.background = if (emp.isOnShift)
                b.root.context.getDrawable(com.burgerclub.stafftracker.R.drawable.bg_status_dot)
            else
                b.root.context.getDrawable(com.burgerclub.stafftracker.R.drawable.bg_status_dot_offline)

            // Selection state
            val isSelected = emp.id == selectedId
            b.cardRoot.background = b.root.context.getDrawable(
                if (isSelected) com.burgerclub.stafftracker.R.drawable.bg_card_selected
                else com.burgerclub.stafftracker.R.drawable.bg_card_normal
            )

            b.root.setOnClickListener { onClick(emp) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemEmployeeCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position), position)

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Employee>() {
            override fun areItemsTheSame(a: Employee, b: Employee) = a.id == b.id
            override fun areContentsTheSame(a: Employee, b: Employee) = a == b
        }
    }
}
