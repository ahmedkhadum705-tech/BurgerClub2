package com.burgerclub.stafftracker.ui.employees

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.burgerclub.stafftracker.data.db.AppDatabase
import com.burgerclub.stafftracker.data.model.Employee
import com.burgerclub.stafftracker.databinding.ActivityEmployeeEditBinding
import kotlinx.coroutines.launch

class EmployeeEditActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEmployeeEditBinding
    private var employeeId: Long = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEmployeeEditBinding.inflate(layoutInflater)
        setContentView(binding.root)

        employeeId = intent.getLongExtra("employee_id", -1L)

        if (employeeId != -1L) {
            loadEmployee(employeeId)
            binding.toolbar.title = "Редактировать сотрудника"
        } else {
            binding.toolbar.title = "Новый сотрудник"
        }
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        binding.btnSave.setOnClickListener { saveEmployee() }
    }

    private fun loadEmployee(id: Long) {
        lifecycleScope.launch {
            val db = AppDatabase.getDatabase(this@EmployeeEditActivity)
            val emp = db.employeeDao().getEmployee(id) ?: return@launch
            binding.etName.setText(emp.name)
            binding.etRate.setText(emp.hourlyRate.toString())
            binding.etPin.setText(emp.pinCode)
            binding.etShiftStart.setText(emp.shiftStartTime)
        }
    }

    private fun saveEmployee() {
        val name = binding.etName.text.toString().trim()
        val rateStr = binding.etRate.text.toString().trim()
        val pin = binding.etPin.text.toString().trim()
        val shiftStart = binding.etShiftStart.text.toString().trim()

        if (name.isEmpty()) { binding.etName.error = "Введите имя"; return }
        if (rateStr.isEmpty()) { binding.etRate.error = "Введите ставку"; return }
        if (pin.isEmpty() || pin.length < 4) { binding.etPin.error = "PIN минимум 4 цифры"; return }
        if (!shiftStart.matches(Regex("\\d{1,2}:\\d{2}"))) {
            binding.etShiftStart.error = "Формат: HH:MM"; return
        }

        val rate = rateStr.toDoubleOrNull() ?: run {
            binding.etRate.error = "Некорректное число"; return
        }

        val employee = Employee(
            id = if (employeeId == -1L) 0 else employeeId,
            name = name,
            hourlyRate = rate,
            pinCode = pin,
            shiftStartTime = shiftStart
        )

        lifecycleScope.launch {
            val db = AppDatabase.getDatabase(this@EmployeeEditActivity)
            if (employeeId == -1L) {
                db.employeeDao().insert(employee)
                Toast.makeText(this@EmployeeEditActivity, "Сотрудник добавлен", Toast.LENGTH_SHORT).show()
            } else {
                db.employeeDao().update(employee)
                Toast.makeText(this@EmployeeEditActivity, "Данные сохранены", Toast.LENGTH_SHORT).show()
            }
            finish()
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
