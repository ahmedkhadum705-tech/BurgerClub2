package com.burgerclub.stafftracker.utils

import java.util.Calendar
import kotlin.math.floor

object SalaryCalculator {

    /**
     * Calculate billed hours applying restaurant rounding rules:
     * - If arrival is more than 10 min late → round start UP to next hour
     * - End time → always round DOWN to last full hour
     *   e.g. 21:50 → bill until 21:00, 22:10 → bill until 22:00
     */
    fun calcBilledHours(checkInMillis: Long, checkOutMillis: Long): Double {
        val inCal = Calendar.getInstance().apply { timeInMillis = checkInMillis }
        val outCal = Calendar.getInstance().apply { timeInMillis = checkOutMillis }

        // Effective start: ceiling to next hour if minutes > 0
        val inMinutes = inCal.get(Calendar.MINUTE)
        val startHour = if (inMinutes > 0) {
            inCal.get(Calendar.HOUR_OF_DAY) + 1
        } else {
            inCal.get(Calendar.HOUR_OF_DAY)
        }

        // Effective end: floor to last full hour
        val endHour = outCal.get(Calendar.HOUR_OF_DAY)
        // If end hour is same day
        val startDay = inCal.get(Calendar.DAY_OF_YEAR)
        val endDay = outCal.get(Calendar.DAY_OF_YEAR)
        val dayDiff = endDay - startDay

        val totalHours = (dayDiff * 24 + endHour - startHour).toDouble()
        return if (totalHours < 0) 0.0 else totalHours
    }

    fun formatHours(hours: Double): String {
        val h = floor(hours).toInt()
        val m = ((hours - h) * 60).toInt()
        return if (m > 0) "${h}ч ${m}м" else "${h}ч"
    }
}
