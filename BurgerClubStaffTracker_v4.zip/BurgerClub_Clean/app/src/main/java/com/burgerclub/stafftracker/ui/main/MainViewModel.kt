package com.burgerclub.stafftracker.ui.main

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.burgerclub.stafftracker.data.model.Employee
import com.burgerclub.stafftracker.data.model.ShiftRecord
import com.burgerclub.stafftracker.data.repository.StaffRepository
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = StaffRepository(app)

    val employees: LiveData<List<Employee>> = repo.getAllEmployees()

    var selectedEmployee: Employee? = null

    fun checkIn(employee: Employee, photoPath: String?, onResult: (Result<ShiftRecord>) -> Unit) {
        viewModelScope.launch {
            val result = repo.checkIn(employee, photoPath)
            onResult(result)
        }
    }

    fun checkOut(employee: Employee, photoPath: String?, onResult: (Result<ShiftRecord>) -> Unit) {
        viewModelScope.launch {
            val result = repo.checkOut(employee, photoPath)
            onResult(result)
        }
    }

    fun getOpenShift(employeeId: Long, onResult: (ShiftRecord?) -> Unit) {
        viewModelScope.launch {
            val shift = repo.getOpenShift(employeeId)
            onResult(shift)
        }
    }
}
