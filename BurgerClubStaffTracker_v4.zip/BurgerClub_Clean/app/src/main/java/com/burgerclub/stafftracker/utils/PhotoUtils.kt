package com.burgerclub.stafftracker.utils

import android.content.Context
import android.graphics.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

object PhotoUtils {

    fun savePhotoWithOverlay(context: Context, bitmap: Bitmap): String {
        val photoDir = File(context.filesDir, "photos")
        if (!photoDir.exists()) photoDir.mkdirs()

        val fileName = "photo_${DateUtils.fileTimestamp()}.jpg"
        val file = File(photoDir, fileName)

        val stamped = stampBitmap(bitmap)

        FileOutputStream(file).use { out ->
            stamped.compress(Bitmap.CompressFormat.JPEG, 90, out)
        }
        stamped.recycle()
        return file.absolutePath
    }

    private fun stampBitmap(source: Bitmap): Bitmap {
        val result = source.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)

        val now = Date()
        val dateStr = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(now)
        val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(now)
        val text = "$dateStr  $timeStr"

        val textPaint = Paint().apply {
            color = Color.WHITE
            textSize = result.width * 0.04f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            isAntiAlias = true
        }

        val bgPaint = Paint().apply {
            color = Color.argb(160, 0, 0, 0)
        }

        val padding = result.width * 0.02f
        val textBounds = Rect()
        textPaint.getTextBounds(text, 0, text.length, textBounds)
        val textH = textBounds.height().toFloat()
        val textW = textPaint.measureText(text)

        val bgRect = RectF(
            padding,
            result.height - textH - padding * 3,
            textW + padding * 3,
            result.height.toFloat() - padding
        )
        canvas.drawRoundRect(bgRect, 8f, 8f, bgPaint)
        canvas.drawText(text, padding * 1.5f, result.height - padding * 1.5f, textPaint)

        return result
    }
}
